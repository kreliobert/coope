<?php
$apibot = "5996451221:AAFbKLLhqOgbNVOpS08Ht_F8ycq7h42aaQI"; 
$canal = "-907895536";
$userp = ""
?>